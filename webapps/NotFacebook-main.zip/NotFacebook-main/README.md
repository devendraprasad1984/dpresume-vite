# NotFacebook
This is more of a Facebook Clone i designed in Figma and later decided to develop. It has a sticky menu and dark mode feature.

View website : https://not-facebook-by-ameer.netlify.app/

<img width="1728" alt="Not Facebook" src="https://user-images.githubusercontent.com/76779409/148857578-d935ca2d-0677-4da3-bf44-37de7c649b26.png">
