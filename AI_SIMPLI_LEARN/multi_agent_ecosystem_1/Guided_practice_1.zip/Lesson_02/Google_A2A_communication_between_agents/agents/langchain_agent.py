from langchain.agents import initialize_agent, AgentType
from langchain_community.chat_models import ChatOpenAI
from langchain.tools import Tool
from langchain.agents import tool

@tool
def extract_task_from_input(input_text):
    """Extract the core task from user input."""
    return f"Extracted task from input: '{input_text.strip()}'"

def create_langchain_agent():
    llm = ChatOpenAI(temperature=0)
    tools = [extract_task_from_input]
    return initialize_agent(tools, llm, agent=AgentType.ZERO_SHOT_REACT_DESCRIPTION, verbose=True)
