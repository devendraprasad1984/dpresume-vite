from crewai import Crew, Agent, Task
from langchain.tools import tool
from langchain.tools.tavily_search import TavilySearchResults
from crewai.tools import BaseTool
from pydantic import BaseModel, Field

import os
os.environ["OPENAI_API_KEY"] = "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"
os.environ["TAVILY_API_KEY"] = "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"


class ToolInput(BaseModel):
  question: str = Field(description= "search query")


class SearchTool(BaseTool):
  name: str = "Search tool"
  description: str = "use this tool to find current information required for query"
  args_schema: type = ToolInput

  def _run(self,question: str):
    """use this tool to find current information required for query"""
    web_search = TavilySearchResults()
    result = web_search.run(question)
    return result

def create_crewai_agent(task_description: str):
    # Create Agent with required fields
    researcher = Agent(
        role="Researcher",
        goal="Search the web and gather information",
        backstory="Expert in web research using advanced techniques",
        tools=[SearchTool()],
        verbose=True,
        allow_delegation=False
    )

    # Create Task with required fields
    task = Task(
        description=task_description,
        expected_output="A summary of web findings relevant to the task",
        agent=researcher,
        output_required=True
    )

    # Assemble Crew
    crew = Crew(
        agents=[researcher],
        tasks=[task],
        verbose=True,
    )

    return crew
