from openai import OpenAI
import os

os.environ["OPENAI_API_KEY"] = "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"
os.environ["TAVILY_API_KEY"] = "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"
def generate_response(prompt: str) -> str:
    from openai import OpenAI
    client = OpenAI(api_key=os.environ["OPENAI_API_KEY"])
    completion = client.chat.completions.create(
        model="gpt-4",
        messages=[{"role": "user", "content": prompt}]
    )
    return completion.choices[0].message.content
