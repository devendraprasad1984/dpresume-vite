python3 -m venv .venv && source .venv/bin/activate
python3 rag_pipeline.py